#!/bin/bash
#
# Exit on first error, print all commands.
set -ev
echo "Cleaning your system environment"
printf "Press 'y' when prompted by the command"
printf "================================"
rm -rf bin/*
rm -rf nodejs/hfc-key-store/*
rm -rf nodejs/node_modules
docker system prune -a

printf "Installing dependancy"
printf "================================"
curl -sSL https://raw.githubusercontent.com/hyperledger/fabric/v1.0.5/scripts/bootstrap.sh | bash -s 1.0.5
