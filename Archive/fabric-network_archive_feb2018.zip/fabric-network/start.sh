#!/bin/bash
#
# Exit on first error, print all commands.
set -ev
# don't rewrite paths for Windows Git Bash users
export MSYS_NO_PATHCONV=1

printf "Building network"
printf "================================"
docker-compose -f docker-compose.yml down
docker-compose -f docker-compose.yml up -d ca.tadev.com orderer.tadev.com peer0.tadev.com peer0.au.com cli

# wait for Hyperledger Fabric to start
# incase of errors when running later commands, issue export FABRIC_START_TIMEOUT=<larger number>
export FABRIC_START_TIMEOUT=15
export OPERATION_TIMEOUT=2

sleep ${FABRIC_START_TIMEOUT}

# Create the channel
# Note: the 2 -e parameters are to indicate the transaction is invoked by the channel administrator
printf "Create the channel"
printf "================================"
docker exec -e "CORE_PEER_LOCALMSPID=OrgTADEVMSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@tadev.com/msp" peer0.tadev.com peer channel create -o orderer.tadev.com:7050 -c tadevchannel -f /etc/hyperledger/configtx/channel.tx

sleep ${OPERATION_TIMEOUT}

printf "Join peer0.tadev.com to the channel"
printf "================================"
# Join peer0.tadev.com to the channel.
docker exec -e "CORE_PEER_LOCALMSPID=OrgTADEVMSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@tadev.com/msp" peer0.tadev.com peer channel join -b tadevchannel.block

printf "Join peer0.au.com to the channel"
printf "================================"
# Join peer0.au.com to the channel.
docker exec -e "CORE_PEER_LOCALMSPID=OrgAUMSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@au.com/msp" peer0.au.com peer channel fetch config tadevchannel.block -o orderer.tadev.com:7050 -c tadevchannel

sleep ${OPERATION_TIMEOUT}

docker exec -e "CORE_PEER_LOCALMSPID=OrgAUMSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@au.com/msp" peer0.au.com peer channel join -b tadevchannel.block

printf "Completed"
printf "================================"

docker ps -a