#!/bin/bash
#
#
# Exit on first error
set -e

# don't rewrite paths for Windows Git Bash users
export MSYS_NO_PATHCONV=1

starttime=$(date +%s)

# set variables
channelName=tadevchannel
chainName=sample
chainVersion=1.0
ordererAddress=orderer.tadev.com:7050

# Install chaincode
docker exec -e "CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/tadev.com/users/Admin@tadev.com/msp" cli peer chaincode install -n fabcar -v 1.0 -p github.com/fabcar
# Instantiate the chaincode - administrator permission
printf '===Instantiate the chaincode - administrator permission==='
docker exec -e "CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/tadev.com/users/Admin@tadev.com/msp" cli peer chaincode instantiate -o orderer.tadev.com:7050 -C tadevchannel -n fabcar -v 1.0 -c '{"Args":[""]}' -P "OR ('OrgTADEVMSP.member','OrgTADEVMSP.member')"
sleep 10
# Invoke the chaincode - administrator permission
printf '===Invoke the chaincode - administrator permission==='
docker exec -e "CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/tadev.com/users/Admin@tadev.com/msp" cli peer chaincode invoke -o orderer.tadev.com:7050 -C tadevchannel -n fabcar -c '{"function":"initLedger","Args":[""]}'

printf "\nTotal setup execution time : $(($(date +%s) - starttime)) secs ...\n\n\n"
printf "Start by installing required packages run 'npm install'\n"
printf "Then run 'node enrollAdmin.js', then 'node registerUser'\n\n"
printf "The 'node invoke.js' will fail until it has been updated with valid arguments\n"
printf "The 'node query.js' may be run at anytime once the user has been registered\n\n"
