#!/bin/sh
export PATH=$GOPATH/src/github.com/hyperledger/fabric/build/bin:${PWD}/bin:${PWD}:$PATH
export FABRIC_CFG_PATH=${PWD}
CHANNEL_NAME=tadevchannel

# remove previous crypto material and config transactions
rm -fr config/*
rm -fr crypto-config/*

# generate crypto material
cryptogen generate --config=./crypto-config.yaml
if [ "$?" -ne 0 ]; then
  echo "Failed to generate crypto material..."
  exit 1
fi

# generate genesis block for orderer
configtxgen -profile TadevOrdererGenesis -outputBlock ./config/genesis.block
if [ "$?" -ne 0 ]; then
  echo "Failed to generate orderer genesis block..."
  exit 1
fi

# generate channel configuration transaction
configtxgen -profile TadevChannel -outputCreateChannelTx ./config/channel.tx -channelID $CHANNEL_NAME
if [ "$?" -ne 0 ]; then
  echo "Failed to generate channel configuration transaction..."
  exit 1
fi

# generate anchor peer update for OrgTADEVMSP
configtxgen -profile TadevChannel -outputAnchorPeersUpdate ./config/OrgTADEVMSPanchors.tx -channelID $CHANNEL_NAME -asOrg OrgTADEVMSP
if [ "$?" -ne 0 ]; then
  echo "Failed to generate anchor peer update for OrgTADEVMSP..."
  exit 1
fi

# generate anchor peer update for OrgAUMSP
configtxgen -profile TadevChannel -outputAnchorPeersUpdate ./config/OrgAUMSPanchors.tx -channelID $CHANNEL_NAME -asOrg OrgAUMSP
if [ "$?" -ne 0 ]; then
  echo "Failed to generate anchor peer update for OrgAUMSP..."
  exit 1
fi