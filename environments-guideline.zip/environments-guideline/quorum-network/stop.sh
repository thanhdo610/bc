#!/bin/bash
killall geth constellation-node
