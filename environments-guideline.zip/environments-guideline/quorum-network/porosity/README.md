This demonstrates how to use Matt Suiche's Porosity decompiler from
inside Quorum. Try to `runscript.sh porosity/deploy-vulnerable.js`,
then `runscript.sh porosity/scan.sh` to see it in action, or use it
interactively in the console with `quorum.runPorosity`.
